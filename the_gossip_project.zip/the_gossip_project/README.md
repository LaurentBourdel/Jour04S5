
* Création du projet gossip:

La page d'accueil,
La page de la team,
La page de contact,
La page de bienvenue,
La page du potin,
La page des villes,
La page des auteurs,

User login & regiter, 
Creation & modification de gossip
...

* Installation:

-> download and unzip: the_gossip_project.zip
-> bundle install
-> rails db:migrate
-> rails db:seed
-> rails server