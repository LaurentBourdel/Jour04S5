class ApplicationController < ActionController::Base
	include SessionsHelper
end
